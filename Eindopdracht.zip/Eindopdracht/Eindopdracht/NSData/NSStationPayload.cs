﻿namespace Eindopdracht.NSData
{
    public class NSStationPayload
    {
        public List<NSStation> Payload { get; set; }
    }
}
