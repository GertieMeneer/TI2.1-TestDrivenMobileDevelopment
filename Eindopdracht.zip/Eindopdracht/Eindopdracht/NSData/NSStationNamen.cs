﻿namespace Eindopdracht.NSData
{
    public class NSStationNamen
    {
        public string Lang { get; set; }
        public string Middel { get; set; }
        public string Kort { get; set; }
    }
}
